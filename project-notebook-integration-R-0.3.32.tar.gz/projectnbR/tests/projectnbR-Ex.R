###############################################################################
# File:        TestProjectUtil
# Version:      0.1.0v
# Description:  This script is used for generating API documentation for
#               for Project-notebook-integration's R APIs and creating the
#               projectnb R package
# Author:       Emily Zhang emilyz@us.ibm.com
# Created:      20161207
# Update:       20161210
#               20161215 Update for Object Store Support
###############################################################################
#   IBM Confidential
# OCO Source Materials
#
# 5737-D37
#
# (C)Copyright IBM Corp. 2017 All Rights Reserved.
#
# The source code for this program is not published or otherwise divested of its trade secrets,
# irrespective of what has been deposited with the U.S. Copyright Office.
#
###############################################################################
##### Catalog ##### 
### User needs to create a Catalog project ###
###############################################################################
#Testing Sacramento CSV Hortonworks
packageVersion("projectnbR")
library(SparkR)
library(projectnbR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d"
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken,"NULL",'qa',FALSE)
df <- loadDataFrameFromConnector(pc,"HortonWorks HDFS CSV connector Sacramento")
head(df)
expectedCount = 985
display(nrow(df))
if (expectedCount == nrow(df)) "success Hortonworks Sacramento" else display(nrow(df))

#Testing Informix customer and Items
dfC <- loadDataFrameFromConnector(pc,"Informix-Customer")
dfI <- loadDataFrameFromConnector(pc,"Informix-Items")
head(dfC)
head(dfI)
expectedCountc = 28
expectedCounti = 67
display(nrow(dfC))
display(nrow(dfI))
if (expectedCountc == nrow(dfC)) "success Informix Customer" else display(nrow(dfC))
if (expectedCounti == nrow(dfI)) "success Informix Items" else display(nrow(dfI))

#Testing UNdata CSV Hortonworks
df1 <- loadDataFrameFromConnector(pc,"HortonWorks HDFS CSV connector UNdata")
head(df1)
expectedCount = 12742
display(nrow(df1))
if (expectedCount == nrow(df1)) "success Hortonworks UNdata" else display(nrow(df1))

#Testing Cloudera
library(SparkR)
library(projectnbR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d"
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken,"NULL",'qa',FALSE)
df2 <- loadDataFrameFromConnector(pc,"Cloudera Public CSV connector")
head(df2)
expectedCount = 1000
display(nrow(df2))
if (expectedCount == nrow(df2)) "success Cloudera" else display(nrow(df2))

#Testing Biginsight Sac
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d"
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken,"NULL",'qa',FALSE)
df3 <- loadDataFrameFromConnector(pc,"BigInsights HDFS CSV connector Sacramento")
head(df3)
expectedCount = 985
display(nrow(df3))
if (expectedCount == nrow(df3)) "success Biginsight Sacramento" else display(nrow(df3))

#Testing Biginsight UNdata
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d"
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken,"NULL",'qa',FALSE)
df4 <- loadDataFrameFromConnector(pc,"BigInsights HDFS CSV connector UNdata")
head(df4)
expectedCount = 12742
display(nrow(df4))
if (expectedCount == nrow(df4)) "success Biginsight UNdata" else display(nrow(df4))

##### Datalake #####
# Test Datalake load/store round-trip functionalities
packageVersion("projectnbR")
library(projectnbR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d"
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken,"NULL",'qa',FALSE)
listAvailableFilesData(pc)
# pick up a datalake file
df <- loadDataFrameFromFile(pc, "movies.csv")
head (df)

df2 <- select(df, "Title", "Year")
df3 <- where (df2, df2$Year > 1970)
head(df3)

result <- storeDataFrameAsFile(pc, df3, "movie6")
if (result) print("Write to Datalake succeeded!") else print("Write to Datalake failed!")

listAvailableFilesData(pc)

##### Connector ##### 
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "db2-employee")
head(df)
if (42 == nrow(df)) "success" else "failure: expected 42 rows"

##### Connector ##### 
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "db2zos-emp")
head(df)
if (42 == nrow(df)) "success" else "failure: expected 42 rows"

##### Connector ##### 
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
# pick up Teradata connector
df <- loadDataFrameFromConnector(pc, "teradata-cloud")
head(df)
if (2 == nrow(df)) "success" else "failure: expected 2 rows"

##### Connector ##### 
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "DashDB_connector_Education")
head(df)
if (17 == nrow(df)) "success" else "failure: expected 17 rows"

##### Connector ##### 
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "DashDB SSL connector Cars")
head(df)
if (3 == nrow(df)) "success" else "failure: expected 3 rows"

##### Connector #####
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "DashDB local connector Sacramento")
head(df)
if (985 == nrow(df)) "success" else "failure: expected 985 rows"

##### Connector #####
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "DashDB local SSL connector UNdata")
head(df)
if (12743 == nrow(df)) "success" else "failure: expected 12743 rows"

#### Connector ####
### User needs to create a project that contains a Netezza connector ###
########################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "Netezza connector food")
head(df)
if (8 == nrow(df)) "success" else "failure: expected 8 rows"

#### Connector ####
### User needs to create a project that contains a Netezza connector ###
########################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "Netezza connector cars")
head(df)
if (19 == nrow(df)) "success" else "failure: expected 19 rows"

#### Connector ####
### User needs to create a project that contains a Oracle connector ###
########################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "Oracle Connection Test - SID")
head(df)
if (14 == nrow(df)) "success" else "failure: expected 14 rows"

##### Connector ##### 
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "db2zos-dept")
head(df)
if (14 == nrow(df)) "success" else "failure: expected 14 rows"

##### Connector ##### 
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "db2-staff")
head(df)
if (35 == nrow(df)) "success" else "failure: expected 35 rows"

##### Connector ##### 
### User needs to create a project that contains a connector  ###
###############################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "DB2-SSL-Sales")
head(df)
if (41 == nrow(df)) "success" else "failure: expected 41 rows"

##### Connector ##### 
### Testing that loadDataFrameFromConnector called with a non existing asset name will return null ###
#######################################################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "1234_NonExistingAsset_98")
if(is.null(df)) "success" else "failure: expected NULL"

##########################################################################################
### Test that, if we have a notebook asset in the common project, called "Object Store Notebook",
### and we check if it exists, it displays "True"
##########################################################################################
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d";
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken, NULL, 'qa', FALSE)
df <- loadDataFrameFromConnector(pc, "DashDB_connector_Education")

fileName <- "Object Store Notebook"
result <- checkIfAssetExists(pc, fileName)
result2 <- storeDataFrameAsObjectStoreFile(pc, df, fileName)
if((result == TRUE) && (result2 == FALSE)) "success" else "failure: expected result = True and result2 = False"

###############################################################################
#####  Object Store ##### 
### User needs to create a Object Store project ###
###############################################################################
library(projectnbR)
projectID <- "156be706-0d73-41f0-b4bc-1942b335abcd";
accessToken <- "p-a0d87f098dd679748c996624ee337714bff818d9"
pc <- ProjectContext(sc, projectID, accessToken)
listAvailableFilesData(pc)
# pick up an object store file
df <- loadDataFrameFromFile(pc, "moviesObjStore.csv")
head (df)

df2 <- select(df, "Title", "Year")
df3 <- where (df2, df2$Year > 1970)
head(df3)

result <- storeDataFrameAsObjectStoreFile(pc, df3, "movie5")
if (result) print("Write to Object Store succeeded!") else print("Write to Object Store failed!")

listAvailableFilesData(pc)

###############################################################################
#####  RDD ##### 
### User needs to create a Datalake or Object Store project ###
###############################################################################
packageVersion("projectnbR")
library(projectnbR)
library(SparkR)
projectID <- "156be706-0d73-41f0-b4bc-1942b335abcd";
accessToken <- "p-a0d87f098dd679748c996624ee337714bff818d9"
pc <- ProjectContext(sc, projectID, accessToken)
listAvailableFilesData(pc)

# Datalake
    rdd1 <- loadRDDFromFile(pc, "movies.csv")
    movieFileData <- FileData("movies.csv", "file/datalake-v1")
#or Object Store
    rdd1 <- loadRDDFromFile(pc, "moviesObjStore.csv")
    movieFileData <- FileData("moviesObjStore.csv", "file/bmos-v3")

rdd2 <- loadRDDFromFile(pc, movieFileData)

# test rdd in Spark 1.6.0
   #count(rdd1)
   #>10
   take(rdd1, count(rdd1))
   take(rdd2, count(rdd2))
# test rdd in Spark 2.0
   # length(rdd1)

# filter
rdd1filter<- SparkR:::filterRDD(rdd1, function(line){ grepl("Alien", line)})
rdd2filter<- SparkR:::filterRDD(rdd2, function(line){ grepl("Rain", line)})

# test rdd in Spark 1.6.0
    take(rdd1filter, count(rdd1filter))
    #> 'Alien, 1979   , Ridley Scott'
    take(rdd2filter, count(rdd2filter))
    #> '"2","Rain",NA," Christine Jeffs"'

### in a Datalake project ### 
    storeRDDAsDatalakeFile(pc, rdd1filter, "movieRDD1filterDL")
    storeRDDAsDatalakeFile(pc, rdd2filter, "movieRDD2filterDL")
### in an Object Store project ### 
    storeRDDAsObjectStoreFile (pc, rdd1filter, "MovieRDD1filter")
    storeRDDAsObjectStoreFile (pc, rdd2filter, "MovieRDD2filter")

listAvailableFilesData(pc)

# Test Store object store file and read back round trip
# Also verify that if there is no object file in the projects ahead, it can still store
# Test with https://apsx-qa.ng.bluemix.net
library(projectnbR)
library(SparkR)
sc <- sparkR.session("local[*]")
projectID <- "657c19bb-4cbf-4c0a-b04a-75ba5009c872"
accessToken <- "p-56c8b31b75d1055ac87b7784445ff1a6c31f1dfd"
pc <- ProjectContext(sc, projectID, accessToken,"NULL",'qa',FALSE)
listAvailableFilesData(pc)

n = c(2, 3, 5) 
s = c("aa", "bb", "cc") 
b = c(TRUE, FALSE, TRUE) 
df2 = data.frame(n, s, b)
df <- as.DataFrame(df2)
if (3 == nrow(df)) "success created df" else display(nrow(df))
if (3 == ncol(df)) "success created df" else display(ncol(df))


filename <- "movie27"
result <- storeDataFrameAsObjectStoreFile(pc, df, filename)
if (result) print("Write to Object Store succeeded!") else print("Write to Object Store failed!")
listAvailableFilesData(pc)
df_result <- loadDataFrameFromFile(pc, filename)
if (3 == nrow(df_result)) "load back success" else display(nrow(df_result))
if (3 == ncol(df_result)) "load back success" else display(ncol(df_result))
