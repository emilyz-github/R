###############################################################################
# File:        ProjectUtil
# Version:      0.1.0v
# Description:  This script is used for generating API documentation for
#               for Project-notebook-integration's R APIs and creating the
#               projectnb R package
# Author:       Emily Zhang emilyz@us.ibm.com
# Created:      20161015 - listAvailableFilesData(pc)
# Updated:      20161021 - clean up
#               20161205 - loadDataFrameFromFile
#               20161207 - storeDataFrameAsFile
#               20161209 - update for packaging
###############################################################################
# ProjectUtil
# Usage:
# listAvailableFilesData(pc)
library(httr)
library(jsonlite)

ProjectsServiceURL_prod = "https://api.apsportal.ibm.com/v2/projects"
#ProjectsServiceURL_prod = "http://9.30.147.188:30044/v2/projects/"
ProjectsServiceURL_qa = "https://ngp-projects-api-qa.ng.bluemix.net/v2/projects"
ProjectsServiceURL_dev = "https://ngp-projects-api-dev.stage1.ng.bluemix.net/v2/projects"
ProjectsServiceURL_YS1_prod = "https://ngp-projects-api.stage1.ng.bluemix.net/v2/projects"
ProjectsServiceURL_onPrem = "http://9.30.147.188:30044/v2/projects/"

DatalakeServiceURL_prod = "https://prod-lb.data-lake.ibm.com/api/v1/data-lake"
DatalakeServiceURL_qa = "https://qa-lb.data-lake.ibm.com/api/v1/data-lake"
DatalakeServiceURL_dev = "https://dev-lb.data-lake.ibm.com/api/v1/data-lake"
DatalakeServiceURL_YS1_prod = "https://stage-lb.data-lake.ibm.com/api/v1/data-lake"

S3Filetype = "S3 File"
DatalakeFiletype = "Datalake File"
ObjectStoreFiletype = "Object Store File"
ConnectionFiletype = "Connection"

ProjectNotDefined1 = "Not defined"
ProjectNotDefined2 = "Undefined"
UntrustedNotebook = "Untrusted notebook"

S3FiletypeID = "file/s3"
DatalakeFiletypeID = "file/datalake-v1"
ObjectStoreFiletypeID = "file/bmos-v3"
ConnectionFiletypeID = "???"

PSEPAssets = "assets" # End Point
PSParamName = "name"
PSParamType = "types"
PSParamValueS3File = S3FiletypeID
PSParamValueDatalakeFile = DatalakeFiletypeID
PSParamValueObjStoreFile = ObjectStoreFiletypeID
PSParamValueDataSet = "dataset/exchange-v1"
PSParamValueConnection = "connection/cdsx-v1"

DLEPComplete = "complete" # End Point
DLParamUseAWSToken = "use_aws_token"

RC_OK = 200
RC_Created_OK = 201

AuthHeader = "Authorization"

EnvID_prod = "prod"
EnvID_qa = "qa"
EnvID_dev = "dev"
EnvID_YS1_prod = "YS1 prod"
InvalidEnvID = "invalid_environment_identifier"

StorageType_ObjectStore = "object_storage"

############################################################
# usage: listAvailableFilesData(pc)
############################################################

# Builds and returns a service URL composed of the given base URL, object id, end-point, and parameter list.
#' @export
composeServiceURL <- function (baseURL, objId1, endPoint, objId2, paramList) {
      urlObjId1 <- if (nchar(objId1) > 0) paste ("/" , objId1, sep="")else ""
      urlEP <- if (nchar(endPoint) > 0) paste("/", endPoint, sep="") else ""
      urlObjId2 <-  if (nchar(objId2) > 0) paste("/", objId2, sep="") else ""
      urlParamList <- if (nchar(paramList)>0) paste("?", paramList, sep="") else ""
      paste (baseURL, urlObjId1, urlEP, urlObjId2, urlParamList, sep="")
}

log <- function (msgString) {
  if (pc$debug) print (msgString)
}

logError <- function (errorString) {
  print(errorString)
}

display <- function (msgString) {
  print (msgString)
}

isOnPrem <- function(pc) {
  pc$environment==ENV_ID_onPrem
}

# Returns a list of file data objects from the given file data JSON string.
#' @export
getFileDataList <- function(pc, filesData) {
     fileDataList <- list()
     fileData <- jsonlite::fromJSON(httr::content(filesData, 'text'))
     for (i in 1:length(fileData$assets$name)) {
         fileDataList = append (fileDataList, paste ("name =", fileData$assets$name[i],
             ", type =", fileData$assets$type[i], sep=""))
     }
     fileDataList
}

# Gets data for files available to the current user from the Projects Service.  The result is
# json strings representing an HTTP response.
#' @export
getAvailableFilesDataFromProjectsService <- function (pc) {
     url <- composeServiceURL(getProjectsServiceURL(pc), pc$projectID, PSEPAssets, "",
     paste(PSParamType, paste(PSParamValueS3File, PSParamValueDatalakeFile, PSParamValueObjStoreFile, sep=","), sep="="))
     log (paste ("getAvailableFilesFromProjectsService URL is", url))
     httpResponse = httr::GET(url, httr::accept_json(), httr::add_headers('Authorization' = pc$accessToken))
     httpResponse
}

#' Gets the Projects service URL to use, based on the current project context.
# the output sample: https://ngp-projects-api-dev.stage1.ng.bluemix.net/v2/projects
#' @export
getProjectsServiceURL <- function (pc){
     projectsServiceURL <- InvalidEnvID
     if (pc$environment == EnvID_prod)
       projectsServiceURL <- ProjectsServiceURL_prod
     else if (pc$environment == EnvID_qa)
       projectsServiceURL <-  ProjectsServiceURL_qa
     else if (pc$environment == EnvID_dev)
       projectsServiceURL <-  ProjectsServiceURL_dev
     else if (pc$environment == EnvID_YS1_prod)
       projectsServiceURL <-  ProjectsServiceURL_YS1_prod
     else if (pc$environment == ENV_ID_onPrem) 
       projectsServiceURL <-  ProjectsServiceURL_onPrem
     projectsServiceURL
}

#' Gets a list of file data structures for the files available to the current user from the project specified
#' in the given project context.
#' @param pc project context
#' @keywords listAvailableFilesData
#' @export
listAvailableFilesData <- function(pc) {
     httpResponse = getAvailableFilesDataFromProjectsService(pc)
     fileDataList <- list()
     if (httpResponse$status_code == RC_OK) {
         fileDataList <- getFileDataList(pc, httpResponse)
     }
     fileDataList
}

############################################################
# usage: df <- loadDataFrameFromFile (pc, "SportsData.csv")
############################################################
#' Gets a list containing the asset type, url and assetData for the file with the given name. 
#' @export
getAssetDataForNamedFile <- function (pc, filesData, fileName){
  log(paste("Getting asset data for file named", fileName))
  assetData <- NULL
  type <- NULL
  url <- NULL
  fileData <- jsonlite::fromJSON(httr::content(filesData, 'text'))
  #log(paste("Getting asset data for filesData:", fileData))
  for (i in 1:length(fileData$assets$name)) {
    if (fileData$assets$name[i] == fileName) {
      assetData <- fileData$assets
      type <- fileData$assets$type[i]
      url <- fileData$assets$url[i]
      #log(paste("Asset data found:", assetData) )
    }
  }
  c(type, url, assetData)
}

#' Gets a list containing the asset data type and url for the file with the given name.
getAssetTypeandURLForNamedFile <- function (pc, filesData, fileName){
    log(paste("Getting asset data for file named ", fileName))
    type <- NULL
    url <- NULL
    fileData <- jsonlite::fromJSON(httr::content(filesData, 'text'))
    for (i in 1:length(fileData$assets$name)) {
    if (fileData$assets$name[i] == fileName) {
      type <- fileData$assets$type[i]
      url <- fileData$assets$url[i]
    }
  }
  c(type, url)
}

#' Gets asset data url for the file with the given name.
# assetURL = getDatalakeURLforNamedFile(pc, filesData, fileName)
#' @export
getDatalakeURLforNamedFile <- function(pc, filesData, fileName){
    log(paste ("Getting url for file named", fileName))
    url <- ""
    fileData <- jsonlite::fromJSON(httr::content(filesData, 'text'))
    for (i in 1:length(fileData$assets$name)) {
        if (fileData$assets$name[i] == fileName
          && fileData$assets$type[i] == DatalakeFiletypeID) {
           url <- fileData$assets$url[i]
        }
    }
    url
}

#' Gets asset access data from the Datalake Service for the asset identified by the given URL.
#' @export
getAssetAccessDataFromDatalakeService <- function(pc, assetURL){
    serviceURL = composeServiceURL(assetURL, "", "", "", paste(DLParamUseAWSToken, "false", sep="="))
    log(paste("getAssetDataFromDatalakeService URL is", serviceURL))
    r = httr::GET(serviceURL, httr::accept_json(), httr::add_headers('Authorization' = pc$accessToken))
    r
}

#' Gets a data frame for the Datalake asset represented by the given asset data.
#' @export
getDataFrameForDatalakeAsset <- function(pc, assetAccessData){
    assetAccessDataJson <- jsonlite::fromJSON(httr::content(assetAccessData, 'text', encoding = "UTF-8"))
    assetId <- assetAccessDataJson$asset_id
    log(paste("asset id is", assetId))
    assetURL = assetAccessDataJson$url
    log(paste("getDataFrameForDatalakeAsset Asset URL is", assetURL))
    log("About to call Spark-CSV service to create a DataFrame")
    asset_df <- read.csv(url(assetURL))
    sparkVersion = utils::packageVersion("SparkR")
    if (grepl('^1', sparkVersion)) {
      df <- createDataFrame(sqlContext, asset_df)
    }
    else if (grepl('^2', sparkVersion)){
      df <- createDataFrame(asset_df, schema = NULL)
    } else {
      logError ("No supported Spark level.")
    }
    
    log("Call to Spark-CSV service completed")
    df
}

# dataFrame <- getDataFrameForNamedFile(pc, httpResponseAvailableFilesData, fileName)
#' Gets a data frame for the named file using the given files data structure obtained from the Projects
#' Service.  The files data structure must be in JSON format. A special error DataFrame is returned if the 
#' requested data frame can't be constructed. 
#' @export
getDataFrameForNamedFile <- function(pc, filesData, fileName)  {
    df <- NULL
    assetData <- getAssetDataForNamedFile(pc, filesData, fileName)
    if (is.null(assetData[3])) {
      logError(paste("No asset data or multiple asset data entries found for file named", fileName))
    } else {
        assetType <- assetData[1]
        assetURL <- assetData[2]
        if (!is.null(assetURL)) {
            log ("Asset data found" )
            log(paste ("asset URL is", assetURL))
            if (assetType == DatalakeFiletypeID) {
              httpResponse = getAssetAccessDataFromDatalakeService(pc, assetURL)
              if (httpResponse$status_code == RC_OK) {
                  log (paste("Response status code is", httpResponse$status_code))
                  df <- getDataFrameForDatalakeAsset(pc, httpResponse)
              } else {
                  logError(paste("Unexpected response code", httpResponse$status_code, "returned from asset access call to Datalake Service"))
              }
            } else if (assetType == ObjectStoreFiletypeID) {
              storageInfo <- getStorageInfoForObjectStore(pc, assetData[3])
              df <- getDataFrameForObjectStoreAsset(pc, assetData[3], storageInfo, fileName)
              #display("Not yet implemented for Object Store Files.")
            } else {
              logError(paste("Unexpected file type", assetType, "found for file", fileName))
            }
        } else {
          logError("DataFrame could not be created due to failure to get asset data for the source file")
        }
    }
   df
}

#' Creates and returns a DataFrame from the content of the named file in the project.  The file must be a CSV file.
#' @param pc project context
#' @param fileName specify the file name
#' @keywords loadDataFrameFromFile
#' @export
loadDataFrameFromFile <- function(pc, fileName){
  display ("Creating DataFrame, this will take a few moments...")
  httpResponseAvailableFilesData <- getAvailableFilesDataFromProjectsService(pc)
  dataFrame <- NULL
  if (httpResponseAvailableFilesData$status_code== RC_OK) { #TRUE
     log("RC OK from getAvailableFilesDataFromProjectsService call")
     dataFrame <- getDataFrameForNamedFile(pc, httpResponseAvailableFilesData, fileName)
     if (!is.null(dataFrame)) display("DataFrame created.")
  } else  {
     logError (paste("Unexpected response code", httpResponseAvailableFilesData$status_code, "returned from available files call to Projects Service"))
  }
  dataFrame
}

###############################################################################################
###                               Store DataFrame to Datalake                               ###
###                  Usage: result <- storeDataFrameAsFile(pc, df3, "movie5")               ###
###############################################################################################
#' Checks if a file with the given name already exists in the Datalake associated with this project and
#' returns an Option containing a boolean that is true if the file exists, otherwise false. If an error
#' is encountered, None is returned.
#' @export
checkIfFileExistsInDatalake <- function(pc, fileName){
    ###
    # Checks if a file with the given name already exists in the Catalog (Datalake) associated with
    # this project and returns true if the file already exists, false if it doesn't, and None if an
    # error is encountered.
    ###
    availFilesResponse = getAvailableFilesDataFromProjectsService(pc)
    checkResult = FALSE
    if (availFilesResponse$status_code == RC_OK){
        log("RC OK from getAvailableFilesDataFromProjectsService call")
        fileData <- jsonlite::fromJSON(httr::content(availFilesResponse, 'text'))
        for (i in 1:length(fileData$assets$name)) {
            if (fileData$assets$name[i] == fileName) {
               checkResult <- TRUE
            }
        }
    }
    else{
        logError(paste("Unexpected response code", availFilesResponse$status_code, "returned when storing file"))
    }
    log(paste("checkIfFileExistsInDatalake returns", checkResult))
    checkResult
}

#' Gets data for a given project from the Projects Service.  The result is
#' an array of strings representing the HTTP response.
#' @export
getProjectDataFromProjectsService <-function(pc){
    ###
    # Gets data for a given project from the Projects Service.  The result is an HTTP response.
    ###
    serviceURL = composeServiceURL(getProjectsServiceURL(pc), pc$projectID, "", "", "")
    #headers = {AuthHeader: pc.accessToken}
    log(paste("getProjectDataFromProjectsService URL is" , serviceURL))
    r = httr::GET(serviceURL, httr::accept_json(), httr::add_headers('Authorization' = pc$accessToken))
    log (paste("stateus code is", r$status_code))
    r
 }

#' Gets the storage ID (guid) associated with the project contained in the given project context.
#' @export
getStorageIdForProject <- function(pc){
    ###
    # Gets the storage type and ID (guid) associated with the project contained in the given project
    # context. The result is a tuple of strings, (<storageType>, <storageId>).  If the values can't be
    # determined, the result is a tuple containing values ("storageTypeNotFound", "storageIdNotFound").
    ###
    storageId <- ""
    projectDataResponse = getProjectDataFromProjectsService(pc)
    if (projectDataResponse$status_code == RC_OK){
        log("RC OK from getProjectDataFromProjectsService call")
        #projectDataJson = projectDataResponse.json()
        projectDataJson <- jsonlite::fromJSON(httr::content(projectDataResponse, 'text')) #, encoding = "ISO-8859-1"))
        entityJson = projectDataJson$entity
        storageJson = entityJson$storage
        # storageType = storageJson$type
        storageId = storageJson$guid
        log(paste("storageId is", storageId))
        # storageTypeAndId = (storageType, storageID)
    }
    storageId
}

#' Gets the Datalake service URL to use, based on the current project context.
#' @export
getDatalakeServiceURL <- function(pc) {
    if (pc$environment == EnvID_prod) DatalakeServiceURL_prod
    else if (pc$environment == EnvID_qa) DatalakeServiceURL_qa
    else if (pc$environment == EnvID_dev) DatalakeServiceURL_dev
    else if (pc$environment == EnvID_YS1_prod) DatalakeServiceURL_YS1_prod
    else InvalidEnvID
  }

#' Initiates a request to the Datalake Service to add a file asset to the Datalake.  The result
#' is an array of strings representing an HTTP response.
#' @export
requestToAddAssetToDatalake <- function (pc, fileName, storageId, projectId){
    url <- composeServiceURL(getDatalakeServiceURL(pc), storageId, "", "", "")
    log(paste("requestToAddAssetToDatalake URL is", url))
    data <- list ("name"  = fileName ,
                  "data_format" = "application/csv",
                  "file_format" ="application/csv",
                  "origin_country" = "US",
                  "use_aws_token" = "false" ,
                  "sandbox_guid" = projectId)
    log(paste("Request to add asset data is", data))
    httpResponse <- httr::POST(url, httr::accept_json(),
                               body = data,
                               httr::add_headers("Authorization" = pc$accessToken),
                               encode = "json")
    log(paste("Request to add asset response code is ", httpResponse$status_code))
    httpResponse
  }


#' Creates and returns a file with the given name from the given Spark data object
#' (that is, an RDD or DataFrame).
#' @export
createFileFromSparkDataObject<- function(pc, sparkDataObj, fileName) {
    ###
    # Creates and returns a file with the given name from the given Spark data object
    # (that is, an RDD or DataFrame).
    ###
    dirPath = file.path(pc$home, 'data', fileName, fsep = .Platform$file.sep)
    filePath = paste(dirPath, ".CSV", sep="")
    log(paste("Temp directory for Spark repartition-write is at", filePath))
    
    sparkVersion = utils::packageVersion("SparkR")
    if (grepl('^1', sparkVersion)) {
      write.csv(SparkR::collect(sparkDataObj), filePath)
    } else if (grepl('^2', sparkVersion)){
      if (inherits(sparkDataObj, 'SparkDataFrame')) {
        #write.csv(SparkR::collect(sparkDataObj), filePath)
        write.df(repartition(sparkDataObj, 1), dirPath, source = "csv", mode = "overwrite")
        log (paste ("***New path is at", dirPath))
        partitionList <- list.files(dirPath)
        tmpFileName <- dirPath
        for (i in 1:length(partitionList)) {
          if (grepl('.csv', partitionList[i])==TRUE) {
            tmpFileName <- partitionList[i]
            break
          }
        }
        filePath <- file.path(dirPath, tmpFileName, fsep = .Platform$file.sep)
        log (paste ("***New file is at path", filePath))
      } else if (inherits(sparkDataObj, "RDD")) {
        write.csv(SparkR:::collectRDD(sparkDataObj), filePath)
        log (paste ("New rdd file is at", filePath))
      } else {
        logError("Unsupported Spark Data Object.")
      }
    } else {
      logError ("No supported Spark level.")
    }

    #log (paste("After write to filePath, file exist is", file.exists(filePath)))
    filePath
}

#' Writes the content of the given file to the Catalog's storage provider using the given URL.
#' @export
writeAssetToDatalake <- function(pc, assetURL, filePath){
    log(paste("Writing content of", filePath, "to Catalog as", assetURL))
    log (paste("Authorization =", pc$accessToken))
    r <-httr::PUT( url = assetURL, body = httr::upload_file(filePath) , headers = "text/csv", Authorization =pc$accessToken)
    log(paste("PUT Status code for assetURL", r$status_code))
    r
}


#' Posts an asset with the given asset ID and URL to the Projects service.  The result is an
#' HTTP response.
#' @export
postAssetToProjectsService <- function(pc, fileName, assetID, datalakeID){
    serviceURL = composeServiceURL(getProjectsServiceURL(pc), pc$projectID, PSEPAssets, "", "" )
    log(paste("postAssetToProjectsService URL is" , serviceURL))
    datalakeURL = paste(getDatalakeServiceURL(pc), "/", datalakeID, "/asset/", assetID, sep="")
    dataList <- list ( assets =
                 list(
                  list(
                   type = DatalakeFiletypeID,
                   name  = fileName,
                   url = datalakeURL,
                   properties =
                       list(asset_id =  assetID,
                        data_format = "text/csv",
                        file_format = "text/csv",
                        sandbox = TRUE)
                 )))
    data <- jsonlite::toJSON(dataList, auto_unbox = TRUE, pretty = TRUE)
    log(paste("Asset data for postAssetToProjectsService is ", data))
    httpResponse <- httr::POST(
        url = serviceURL,
        body = data,
        httr::content_type("application/json"),
        httr::accept_json(),
        httr::add_headers(Authorization = pc$accessToken),
        httr::verbose()
        )
    log(paste("postAssetToProjectsService Request to add asset response code is", httpResponse$status_code))
    httpResponse
}

#' Notifies the Datalake Service that the process of writing the asset to storage is completed.
#' @export
notifyDatalakeServiceAddAssetComplete <- function(pc, assetID, datalakeID){
    ###
    # Notifies the Catalog Service that the process of writing the asset to storage is completed.
    ###
    serviceURL = composeServiceURL(getDatalakeServiceURL(pc), datalakeID, paste("asset/", assetID, sep=""), DLEPComplete, "")
    log(paste("notifyDatalakeServiceAddAssetComplete URL is", serviceURL))
    data = ""
    # headers = {AuthHeader: pc.accessToken, 'Content-Type': 'application/json', 'Accept': 'application/json' }
    # httpResponse <- httr::POST(url, accept_json(),
    #                           body = data,
    #                           add_headers("Authorization" = pc$accessToken),
    #                           encode = "json")
    r = httr::POST(serviceURL, httr::accept_json(), body = data, httr::add_headers("Authorization" = pc$accessToken), encode = "json")
    log(paste("Notify Catalog service that write of asset completed response code is", r$status_code))
    r
}

#' Adds a file asset with the given asset ID and asset URL to the current project.
#' @export
addFileAssetToProject <- function(pc, fileName, assetID, datalakeID){
    ###
    # Adds a file asset with the given asset ID and asset URL to the current project.
    ###
    addFileAssetToProjectResult = FALSE
    postAssetResponse = postAssetToProjectsService(pc, fileName, assetID, datalakeID)
    if (postAssetResponse$status_code == RC_OK){
        log("Post asset to project service was successful!")
        addFileAssetToProjectResult = TRUE
    }
    else{
        logError(paste("Posting asset to project service failed, RC is", postAssetResponse$status_code))
    }
    addFileAssetToProjectResult
}

#' Stores the content of the given Spark data object as a new project file with the given name in the 
#'  Datalake service.
#' @export
storeSparkDataObjectAsDatalakeFile <- function(pc, sparkData, fileName) {
    storeResult = FALSE
    checkResultOpt = checkIfFileExistsInDatalake(pc, fileName)
    if (checkResultOpt) {
        logError(paste("A file with name", fileName, "already exists in the Datalake"))
    } else {
        # Continue to store the file
        storageId <- getStorageIdForProject(pc)
        if (storageId == "storageIdNotFound") {
          logError("Could not obtain storage ID for Datalake Service.")
        }
        else {
            httpResponse = requestToAddAssetToDatalake(pc, fileName, storageId, pc$project_id)
            if (httpResponse$status_code == RC_OK) {
                    log("Request to add asset to Datalake succeeded!")
                    responseJson <- jsonlite::fromJSON(httr::content(httpResponse, 'text', encoding = "ISO-8859-1"))
                    assetId = responseJson$"asset_id"
                    url = responseJson$"url"
                    log(paste("ID is for new Datalake asset is", assetId))
                    log(paste("Write URL for new Datalake asset is", url))
                    filePath = createFileFromSparkDataObject(pc, sparkData, fileName)
                    log(paste("New file is at ", filePath))
                    #log(paste("Getting line iterator for file ", filePath))
                    log ("About to writeAssetToDatalake")
                    writeRC = writeAssetToDatalake(pc, url, filePath)
                    if (writeRC$status_code == RC_Created_OK || writeRC$status_code == RC_OK) {
                            display("DataFrame write to storage service succeeded!")
                            httpResponse2 <- notifyDatalakeServiceAddAssetComplete(pc, assetId, storageId)
                            if (httpResponse2$status_code == RC_OK)  {
                                log("Notify-complete call to Datalake Service succeeded!")
                                addFileAssetToProjectResult = addFileAssetToProject(pc, fileName, assetId, storageId)
                                display(paste("Add data asset to project",
                                    (if (addFileAssetToProjectResult) "succeeded!" else "failed!")))
                                storeResult = addFileAssetToProjectResult
                                display("Storing DataFrame completed.")
                            } else {
                                logError("Notify complete call to Datalake Service failed!")
                            } #end of math for httpResponse2.code
                    } else {
                            logError("DataFrame write to Datalake failed!")
                    } # end of math of writeRC
                    log(paste("Deleting temp file: ", filePath))
                    #delete file
                    file.remove(filePath)
            } else {
                     logError("Request to add asset to Datalake failed!")
            } # end of math of httpResponse
        } # end of check storageId
      } # end of check if file exists
      storeResult
}

#' Stores the content of the given data frame as a new project file with the given name.  The file will be
#' a CSV file and will be stored in the Datalake. 
#' @param pc project context
#' @param df dataframe
#' @param fileName new file name
#' @keywords storeDataFrameAsFile
#' @export
storeDataFrameAsFile <- function (pc, df, fileName) {
    display ("Storing DataFrame, this will take a few moments...")
    storeSparkDataObjectAsDatalakeFile(pc, df, fileName)
}
