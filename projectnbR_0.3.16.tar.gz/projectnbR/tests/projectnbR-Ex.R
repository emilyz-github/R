###############################################################################
# File:        TestProjectUtil
# Version:      0.1.0v
# Description:  This script is used for generating API documentation for
#               for Project-notebook-integration's R APIs and creating the
#               projectnb R package
# Author:       Emily Zhang emilyz@us.ibm.com
# Created:      20161207
# Update:       20161210
#               20161215 Update for Object Store Support
###############################################################################

##### Catalog ##### 
### User needs to create a Catalog project ###
###############################################################################
library(projectnbR)
projectID <- "72a068ef-16af-4c8f-986e-e87229242418";
accessToken <- "p-2fb720b5a707c01c57c119ba294d7dedb9179285"
pc <- ProjectContext(sc, projectID, accessToken)
listAvailableFilesData(pc)
# pick up a datalake file
df <- loadDataFrameFromFile(pc, "movies.csv")
head (df)

df2 <- select(df, "Title", "Year")
df3 <- where (df2, df2$Year > 1970)
head(df3)

result <- storeDataFrameAsFile(pc, df3, "movie6")
if (result) print("Write to Datalake succeeded!") else print("Write to Datalake failed!")

listAvailableFilesData(pc)

###############################################################################
#####  Object Store ##### 
### User needs to create a Object Store project ###
###############################################################################
library(projectnbR)
projectID <- "156be706-0d73-41f0-b4bc-1942b335abcd";
accessToken <- "p-a0d87f098dd679748c996624ee337714bff818d9"
pc <- ProjectContext(sc, projectID, accessToken)
listAvailableFilesData(pc)
# pick up an object store file
df <- loadDataFrameFromFile(pc, "moviesObjStore.csv")
head (df)

df2 <- select(df, "Title", "Year")
df3 <- where (df2, df2$Year > 1970)
head(df3)

result <- storeDataFrameAsObjectStoreFile(pc, df3, "movie5")
if (result) print("Write to Object Store succeeded!") else print("Write to Object Store failed!")

listAvailableFilesData(pc)

###############################################################################
#####  RDD ##### 
### User needs to create a Datalake or Object Store project ###
###############################################################################
packageVersion("projectnbR")
library(projectnbR)
library(SparkR)
projectID <- "156be706-0d73-41f0-b4bc-1942b335abcd";
accessToken <- "p-a0d87f098dd679748c996624ee337714bff818d9"
pc <- ProjectContext(sc, projectID, accessToken)
listAvailableFilesData(pc)

# Datalake
    rdd1 <- loadRDDFromFile(pc, "movies.csv")
    movieFileData <- FileData("movies.csv", "file/datalake-v1")
#or Object Store
    rdd1 <- loadRDDFromFile(pc, "moviesObjStore.csv")
    movieFileData <- FileData("moviesObjStore.csv", "file/bmos-v3")

rdd2 <- loadRDDFromFile(pc, movieFileData)

# test rdd in Spark 1.6.0
   #count(rdd1)
   #>10
   take(rdd1, count(rdd1))
   take(rdd2, count(rdd2))
# test rdd in Spark 2.0
   # length(rdd1)

# filter
rdd1filter<- SparkR:::filterRDD(rdd1, function(line){ grepl("Alien", line)})
rdd2filter<- SparkR:::filterRDD(rdd2, function(line){ grepl("Rain", line)})

# test rdd in Spark 1.6.0
    take(rdd1filter, count(rdd1filter))
    #> 'Alien, 1979   , Ridley Scott'
    take(rdd2filter, count(rdd2filter))
    #> '"2","Rain",NA," Christine Jeffs"'

### in a Datalake project ### 
    storeRDDAsDatalakeFile(pc, rdd1filter, "movieRDD1filterDL")
    storeRDDAsDatalakeFile(pc, rdd2filter, "movieRDD2filterDL")
### in an Object Store project ### 
    storeRDDAsObjectStoreFile (pc, rdd1filter, "MovieRDD1filter")
    storeRDDAsObjectStoreFile (pc, rdd2filter, "MovieRDD2filter")

listAvailableFilesData(pc)