###############################################################################
# IBM Confidential
# OCO Source Materials
#
# 5737-D37
#
# (C)Copyright IBM Corp. 2017 All Rights Reserved.
#
# The source code for this program is not published or otherwise divested of its trade secrets,
# irrespective of what has been deposited with the U.S. Copyright Office.
#
###############################################################################
library(SparkR)
library(random)
sc <- sparkR.session("local[*]")
projectID <- "9de03219-1b9e-4067-b02d-cf0f4d76d85d"
accessToken <- "p-eb1ec0d3f13cf4499f6d9a8f2de517389740fe20"
pc <- ProjectContext(sc, projectID, accessToken,"NULL",'qa',FALSE)

context("testProjectUtil")

test_that("test db2zos-emp", {
  df <- loadDataFrameFromConnector(pc, "db2zos-emp")
  expect_equal(nrow(df), 42)
})

test_that("test db2zos-dept", {
  df <- loadDataFrameFromConnector(pc, "db2zos-dept")
  expect_equal(nrow(df), 14)
})

test_that("test db2-employee", {
  df <- loadDataFrameFromConnector(pc, "db2-employee")
  expect_equal(nrow(df), 42)
})

test_that("test db2-staff", {
  df <- loadDataFrameFromConnector(pc, "db2-staff")
  expect_equal(nrow(df), 35)
})

# test_that("test DB2-SSL-Sales", {
#   df <- loadDataFrameFromConnector(pc, "DB2-SSL-Sales")
#   expect_equal(nrow(df), 41)
# })

test_that("test DashDB local connector Sacramento", {
  df <- loadDataFrameFromConnector(pc, "DashDB local connector Sacramento")
  expect_equal(nrow(df), 985)
})

test_that("test DashDB local SSL connector UNdata", {
  df <- loadDataFrameFromConnector(pc, "DashDB local SSL connector UNdata")
  expect_equal(nrow(df), 12743)
})

test_that("test DashDB_connector_Education", {
  df <- loadDataFrameFromConnector(pc, "DashDB_connector_Education")
  expect_equal(nrow(df), 17)
})

test_that("test DashDB SSL connector Cars", {
  df <- loadDataFrameFromConnector(pc, "DashDB SSL connector Cars")
  expect_equal(nrow(df), 3)
})

test_that("test Netezza connector food", {
  df <- loadDataFrameFromConnector(pc, "Netezza connector food")
  expect_equal(nrow(df), 8)
})
 
test_that("test Netezza connector cars", {
  df <- loadDataFrameFromConnector(pc, "Netezza connector cars")
  expect_equal(nrow(df), 19)
})

test_that("test Informix-Customer", {
  df <- loadDataFrameFromConnector(pc, "Informix-Customer")
  expect_equal(nrow(df), 28)
})

test_that("test Informix-Items", {
  df <- loadDataFrameFromConnector(pc, "Informix-Items")
  expect_equal(nrow(df), 67)
})

test_that("test teradata-cloud", {
  df <- loadDataFrameFromConnector(pc, "teradata-cloud")
  expect_equal(nrow(df), 2)
})

test_that("test Oracle Connection Test - SID", {
  df <- loadDataFrameFromConnector(pc, "Oracle Connection Test - SID")
  expect_equal(nrow(df), 14)
})

test_that("test BigInsights HDFS CSV connector Sacramento", {
  df <- loadDataFrameFromConnector(pc, "BigInsights HDFS CSV connector Sacramento")
  expect_equal(nrow(df), 985)
})

test_that("test BigInsights HDFS CSV connector UNdata", {
  df <- loadDataFrameFromConnector(pc, "BigInsights HDFS CSV connector UNdata")
  expect_equal(nrow(df), 12742)
})

test_that("test Cloudera Public CSV connector", {
  df <- loadDataFrameFromConnector(pc, "Cloudera Public CSV connector")
  expect_equal(nrow(df), 1000)
})

 test_that("test HortonWorks HDFS CSV connector Sacramento connector connector", {
   df_connector <- loadDataFrameFromConnector(pc, "HortonWorks HDFS CSV connector Sacramento")
   expect_equal(nrow(df_connector), 985)
   # fileName <- randomStrings(n=1, len=8, digits=TRUE, upperalpha=TRUE,loweralpha=TRUE, unique=TRUE, check=TRUE)
   # objStore <- storeDataFrameAsObjectStoreFile(pc, df_connector, fileName)
   # df_file <- loadDataFrameFromFile(pc, fileName)
   # expect_equal(nrow(df_file), 985)
   # expect_identical(df_connector, df_file)
})

test_that("test HortonWorks HDFS CSV connector UNdata connector", {
  df_connector <- loadDataFrameFromConnector(pc, "HortonWorks HDFS CSV connector UNdata")
  expect_equal(nrow(df_connector), 12742)
})

test_that("test that loadDataFrameFromConnector returns NULL for an asset that does not exist", {
  df <- loadDataFrameFromConnector(pc, "1234_NonExistingAsset_98")
  expect_equal(df, NULL)
})

test_that("test that checkIfAssetExists returns TRUE for a notebook that exists", {
  df <- loadDataFrameFromConnector(pc, "DashDB_connector_Education")
  fileName <- "Object Store Notebook"
  result <- checkIfAssetExists(pc, fileName)
  expect_equal(result, TRUE)
})

test_that("test that storeDataFrameAsObjectStoreFile returns FALSE for a filename of an asset that already exists", {
  df <- loadDataFrameFromConnector(pc, "DashDB_connector_Education")
  fileName <- "Object Store Notebook"
  result <- storeDataFrameAsObjectStoreFile(pc, df, fileName)
  expect_equal(result, FALSE)
})

#Information of csv file for csv option automation test
#The list of inferschema is as below
#[('street', 'string'), ('city', 'string'), ('zip', 'int'), ('state', 'string'), ('beds', 'int'), ('baths', 'int'), ('sq__ft', 'int'), 
# ('type', 'string'), ('sale_date', 'string'), ('price', 'int'), ('latitude', 'double'), ('longitude', 'double')]
#Total 12 columns

test_that("test that csv automation Header on Infer on", {
  dfHeaderOnInferOn <- loadDataFrameFromConnector(pc,"HortonWorks HDFS CSV connector Sacramento")
  #Header on InferSchema off is using common Hortonworks Sacramento file
  expect_equal(nrow(dfHeaderOnInferOn), 985)
  #Check header on functionality
  expect_equal(dtypes(dfHeaderOnInferOn)[3][[1]][2], "int")
  expect_equal(dtypes(dfHeaderOnInferOn)[1][[1]][1], "street")
  #Unlike 2-level list in Python and Scala, R offers 3-level list. The 1st level has 12 elements for 12 columns.
  #The 2nd level only has 1 element. The 3rd level has 2 elements, the header and the type of this column
})

test_that("test that csv automation Header on Infer off", {
  dfHeaderOnInferOff <- loadDataFrameFromConnector(pc,"HortonWorks HDFS CSV connector Sacramento OFFON")
  #Header on InferSchema off is using common Hortonworks Sacramento file
  expect_equal(nrow(dfHeaderOnInferOff), 985)
  #Double check header on functionality
  #if InferSchema is on, this column should be int
  expect_equal(dtypes(dfHeaderOnInferOff)[3][[1]][2], "string")
  expect_equal(dtypes(dfHeaderOnInferOff)[1][[1]][1], "street")
  #Unlike 2-level list in Python and Scala, R offers 3-level list. The 1st level has 12 elements for 12 columns.
  #The 2nd level only has 1 element. The 3rd level has 2 elements, the header and the type of this column
})

test_that("test that csv automation Header off Infer on", {
  dfHeaderOffInferOn <- loadDataFrameFromConnector(pc,"Cloudera Public CSV connector No Header")
  #Header off InferSchema on is using Cloudera no header csv file
  expect_equal(nrow(dfHeaderOffInferOn), 985)
  #Checking row count of Cloudera no header
  expect_equal(dtypes(dfHeaderOffInferOn)[12][[1]][2], "double")
  expect_equal(dtypes(dfHeaderOffInferOn)[1][[1]][1], "_c0")
  #Unlike 2-level list in Python and Scala, R offers 3-level list. The 1st level has 12 elements for 12 columns.
  #The 2nd level only has 1 element. The 3rd level has 2 elements, the header and the type of this column
})

test_that("test that csv automation Header off Infer off", {
  dfHeaderOffInferOff <- loadDataFrameFromConnector(pc,"Cloudera Public CSV connector No Header InferSchema off")
  #Header off InferSchema off is using Cloudera No header No InferSchema file as a double check header on/off functionality
  expect_equal(nrow(dfHeaderOffInferOff), 985)
  #Double check header off functionality. Using Cloudera no header InferSchema off
  expect_equal(dtypes(dfHeaderOffInferOff)[3][[1]][2], "string")
  #if InferSchema is on, this one should be double
  expect_equal(dtypes(dfHeaderOffInferOff)[1][[1]][1], "_c0")
  #Unlike 2-level list in Python and Scala, R offers 3-level list. The 1st level has 12 elements for 12 columns.
  #The 2nd level only has 1 element. The 3rd level has 2 elements, the header and the type of this column
})
# test_that("test loadDataFrameFromFile with predefined object store file and roundtrip", {
#   df <- loadDataFrameFromFile(pc, "moviesObjStore.csv")
#   df2 <- select(df, "Title", "Year")
#   df3 <- where (df2, df2$Year > 1970)
#   fileName <- randomStrings(n=1, len=8, digits=TRUE, upperalpha=TRUE,loweralpha=TRUE, unique=TRUE, check=TRUE)
#   result <- storeDataFrameAsObjectStoreFile(pc, df, fileName)
#   expect_equal(result, TRUE)
# })

# test_that("test storeDataFrameAsObjectStoreFile with predefined dataframe and roundtrip", {
#   n = c(2, 3, 5)
#   s = c("aa", "bb", "cc")
#   b = c(TRUE, FALSE, TRUE)
#   df2 = data.frame(n, s, b)
# 
#   df <- as.DataFrame(df2)
#   expect_equal(nrow(df), 3)
#   expect_equal(ncol(df), 3)
# 
#   fileName <- randomStrings(n=1, len=8, digits=TRUE, upperalpha=TRUE,loweralpha=TRUE, unique=TRUE, check=TRUE)
#   result <- storeDataFrameAsObjectStoreFile(pc, df, fileName)
#   expect_that(result, TRUE)
# 
#   df_result <- loadDataFrameFromFile(pc, fileName)
#   expect_that(nrow(df_result), 3)
#   expect_that(ncol(df_result), 3)
# })