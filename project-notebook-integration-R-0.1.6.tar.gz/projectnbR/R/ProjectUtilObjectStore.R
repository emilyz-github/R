###############################################################################
# File:        ProjectUtilObjectStore
# Version:      0.1.0v
# Description:  This script is used for generating API documentation for
#               for Project-notebook-integration's R APIs and creating the
#               projectnb R package
# Author:       Emily Zhang emilyz@us.ibm.com
# Created:      20161015 - listAvailableFilesData(pc)
# Updated:      20161021 - clean up
#               20161205 - loadDataFrameFromFile
#               20161207 - storeDataFrameAsFile
#               20161209 - update for packaging
###############################################################################
# ProjectUtil
# Usage:
# listAvailableFilesData(pc)

############################################################
# usage: listAvailableFilesData(pc)
############################################################
#'
#'  * Gets storage info from Projects service for the Object Store associated with the project.
#'* Note: if the project is an "Object Store" project, the storage info is defined once for the
#'* entire project.  If the project is a "Catalog" (Data lake) project, then the storage info is
#'* contained in the given asset (file) data object.
#'
#' @export
getStorageInfoForObjectStore <- function(pc, assetData) {
    serviceURL = paste(getProjectsServiceURL(pc), "/", pc$projectID, sep="")
    log(paste("getStorageInfoForObjectStoreURL is", serviceURL))
    # httpResponse = Http(url).headers(Seq(AuthHeader -> pc.accessToken)).asString
    httpResponse= httr::GET(serviceURL, httr::accept_json(), httr::add_headers('Authorization' = pc$accessToken))
    
    if (httpResponse$status_code == RC_OK) {
        responseBody = jsonlite::fromJSON(httr::content(httpResponse, 'text', encoding="UTF-8"))
        log(paste("getStorageInfoForObjectStore responseBody is", responseBody))
        tmpInfo = responseBody$storage
        storageInfo = if ( tmpInfo$type == StorageType_ObjectStore) tmpInfo else assetData
        log("getStorageInfoForObjectStoreAsset is Ok")
    } else {
        logError(paste("Unexpected response code", httpResponse$status_code, "returned from available files call to Projects Service"))
        storageInfo = "StorageInfoNotFound"
    }
    storageInfo
}
  
#' Creates and returns a map of the asset data values that we need from the given JSON structure.
#' @export
getAssetDataMap <- function(pc, filename, storageInfo) {
        assetDataMap = list()
        assetDataMap$filename <- if (is.null(filename)) "filename not found" else filename  
        assetDataMap$projectID <- if (is.null(storageInfo$projectId)) "project ID not found" else storageInfo$projectId  
        assetDataMap$container <- if (is.null(storageInfo$container)) "container not found" else storageInfo$container 
        assetDataMap$region <- if (is.null(storageInfo$region)) "region not found" else storageInfo$region  
        assetDataMap$userID <- if (is.null(storageInfo$userId)) "user ID not found" else storageInfo$userId  
        assetDataMap$password <- if (is.null(storageInfo$password)) "password not found" else storageInfo$password  
        assetDataMap$authURL <- if (is.null(storageInfo$auth_url)) "auth URL not found" else paste(storageInfo$auth_url, "/v3/auth/tokens") 
        assetDataMap
}

#' Authenticates with an Object Store using the given auth URL, user ID, password, and project ID. 
#' @export
authenticateWithObjectStore <- function(pc, authURL, userID, password, projectID) {
    log(paste("authenticate object store, URL =", authURL, ", user ID =", userID, ", project ID = ", projectID))
    requestBodyList = list(
      auth = list(
        identity = list (
          methods = list("password"),
          password = list (
            user = list (
              id =  userID,
              password = password
            )
          )
        ),
        scope = list(
          project = list(
            id = projectID
          )
        )
      )
    )
    requestBody <- jsonlite::toJSON(requestBodyList, auto_unbox = TRUE, pretty = TRUE)
    # httpRequest = Http(authURL).postData(requestBody).header("Content-Type", "application/json")
    httpResponse <- httr::POST(
      url = authURL,
      body = requestBody,
      httr::content_type("application/json"),
      httr::accept_json(),
      httr::add_headers(Authorization = pc$accessToken),
      httr::verbose()
    )
    httpResponse
  }

#' Derives and returns a URL for accessing the Object Store from the given authorization response body, region, 
#' container, and file name. 
#' @export
getObjectStoreURLFromAuthResponseBody <- function(pc, authResponseBody, requiredRegion, container, filename){
    
     typeIndex = match('object-store', authResponseBody$token$catalog$type)
     endpoints <- authResponseBody$token$catalog$endpoints[typeIndex][[1]]
     urlInd = which((endpoints[,3]==requiredRegion & endpoints[,4]=="public"))
     urlStr = endpoints[urlInd, 2]
    
    objectStoreURL = paste(urlStr, "/", gsub(" ", "%20", container), "/", gsub(" ", "%20", filename))
    objectStoreURL
  }

#' Gets a data frame for the ObjectStore asset represented by the given asset data. 
#' @export    
getDataFrameForObjectStoreAsset <-function(pc, assetData, storageInfo, filename){
    assetDataMap = getAssetDataMap(pc, filename, storageInfo)
    
    #filename = assetDataMap$filename
    projectID = assetDataMap$projectID
    container = assetDataMap$container
    region = assetDataMap$region
    userID = assetDataMap$userID
    password = assetDataMap$password
    authURL = assetDataMap$authURL
    
    dataFrame <- NULL
    authResponse = authenticateWithObjectStore(pc, authURL, userID, password, projectID)
    if (authResponse$status_code == RC_Created_OK) {
        #authResponseHeaders <- authResponse$headers
        authToken = authResponse$header$'x-subject-token'
        log(paste("Object Store auth token is", authToken))
        #fileData <- jsonlite::fromJSON(httr::content(availFilesResponse, 'text'))
        authResponseBody = jsonlite::fromJSON(httr::content(authResponse, 'text', encoding="UTF-8"))
        objStoreURL = getObjectStoreURLFromAuthResponseBody(pc, authResponseBody, region, container, filename) #TODO
        log(paste("Object Store URL is", objStoreURL))
        log("About to call Spark-CSV service to create a DataFrame")
        asset_df <- read.csv(url(objStoreURL))
        dataFrame <- createDataFrame(sqlContext, asset_df)
        log("Call to Spark-CSV service completed")
        dataFrame
      }
      else {
        log(paste("Authorization could not be objtained for the Object Store, RC =", authResponse$status_code))
        #createErrorDataFrame(pc, "DataFrame could not be created from Object Store asset")
      }
    dataFrame
  }
