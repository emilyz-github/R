###############################################################################
# File:        ProjectUtilObjectStore
# Version:      0.1.0v
# Description:  This script is used for generating API documentation for
#               for Project-notebook-integration's R APIs and creating the
#               projectnb R package
# Author:       Emily Zhang emilyz@us.ibm.com
# Created:      20170103 - Support RDD
# Updated:      
#               20161212 - loadDataFrameFromFile
#               20161214 - storeDataFrameAsFile
#               20161214 - update for packaging
#               20160110 - add Spark 2 support
###############################################################################
# ProjectUtil
# Usage:
# listAvailableFilesData(pc)
# loadRDDFromFile(pc, fileName)

############################################################
# usage: loadRDDFromFile(pc, fileName)
############################################################
#' Creates and returns a RDD from the content of the named file in the project. 
#' Creates and returns a RDD from the content of the file referenced by the given file data object. 
#' @export
   loadRDDFromFile <- function (pc, fileNameObj) {
     rdd <- NULL
     if (inherits(fileNameObj, 'FileData')) {
       rdd <- loadRDDFromFile (pc, fileNameObj$fileName)
     } else if (inherits(fileNameObj, "character")){
        display("Creating RDD, this will take a few moments...")
        httpResponse = getAvailableFilesDataFromProjectsService(pc)
  
        if (httpResponse$status_code == RC_OK) {
            #log("RC OK from getAvailableFilesDataFromProjectsService call")
            rdd = getRDDForNamedFile(pc, httpResponse, fileNameObj)
            if (!is.null(rdd)) 
              display("RDD created.")
            
        } else {
            logError(paste("Unexpected response code", httpResponse$status_code, "returned from available files call to Projects Service"))
            #ProjectUtilImpl.createErrorRDD(pc, "RDD could not be created due to failure to get available files data from project service")
        }
     } else {
       logError("error with the file name")
    }
      rdd
  }

#' file data object
#' @param fileName_val file name
#' @param fileType_val file type
#' @export
  FileData <- function(fileName_val, fileType_val) {
       me <- list(
         fileName = fileName_val,
         fileType = fileType_val
       )
       
       ## Set the name for the class
       class(me) <- append(class(me), "FileData")
       return(me)
  }  
     
#' Gets an RDD for the named file using the given files data structure obtained from the Projects
#' Service.  The files data structure must be in JSON format. A special error RDD is returned if the RDD can't
#' be constructed. 
#' @export
  getRDDForNamedFile<- function (pc, filesData, fileName)  {
    rdd <- NULL
    assetData = getAssetDataForNamedFile(pc, filesData, fileName)
    if (is.null(assetData[3])) {
      logError(paste("No asset data or multiple asset data entries found for file named", fileName))
    } else {
      fileType <- assetData[1]
      assetURL <- assetData[2]
      if (!is.null(assetURL)) {
           log ("Asset data found" )
           log(paste ("asset URL is", assetURL))
           #fileType = (assetData \\ "type").values.toString
           if (fileType == S3FiletypeID | fileType == DatalakeFiletypeID)  {
              #assetID = (assetData \\ "asset_id").values.toString
              # log(paste("asset id is " , assetID))
              #assetURL = (assetData \ "url").values.toString
              #log(paste("asset URL is " , assetURL))
              httpResponse = getAssetAccessDataFromDatalakeService(pc, assetURL)
              if (httpResponse$status_code == RC_OK)  {
                  #assetAccessData = httpResponse.body
                  rdd <- getRDDForDatalakeAsset(pc, httpResponse)
              } else {
                  logError(paste("Unexpected response code", httpResponse$status_code, "returned from asset access call to Datalake Service"))
                  #createErrorRDD(pc, "RDD could not be created due to failure to access Datalake service")
              }
            } else if (fileType == ObjectStoreFiletypeID) {
              storageInfo <- getStorageInfoForObjectStore(pc, assetData[3])
              rdd <- getRDDForObjectStoreAsset(pc, assetData[3], storageInfo, fileName)
            } else {
              logError(paste("Unexpected file type", fileType, "found for file", fileName))
              #createErrorRDD(pc, "RDD could not be created due to invalid file type for file " + fileName)
            }
        } else {
          logError("RDD could not be created due to failure to get asset data for the source file")
        }
    }
  }
  
#' Gets an RDD for the Datalake asset represented by the given asset data. 
#' @export
    getRDDForDatalakeAsset <- function (pc, assetAccessData) {
      assetAccessDataJson <- jsonlite::fromJSON(httr::content(assetAccessData, 'text', encoding = "UTF-8"))
      assetId <- assetAccessDataJson$asset_id
      log(paste("asset id is", assetId))
      assetURL = assetAccessDataJson$url
      log(paste("getDataFrameForDatalakeAsset Asset URL is", assetURL))
      
      #og("About to call Spark-CSV service to create a RDD")
      #ilePath = pc.home + File.separator + "data" + File.separator + assetId + ".CSV"
      filePath = file.path(pc$home, 'data', paste(assetId, ".CSV", sep=""), fsep = .Platform$file.sep)
      log(paste("filePath is", filePath))
      
      asset_df <- read.csv(url(assetURL))
      write.csv(asset_df, filePath)
      #rdd <- pc.sc.textFile(asset_df)
      rdd <- SparkR:::textFile(sc, filePath)
      
      # delete file
      # log(paste("Deleting temp file: ", filePath))
      # file.remove(filePath)
      
      rdd
    }
  

#' Gets a data frame for the ObjectStore asset represented by the given asset data. 
#' @export
      getRDDForObjectStoreAsset <- function (pc, assetData, storageInfo, fileName) {
        assetDataMap = getAssetDataMap(pc, assetData, storageInfo)

        projectID = assetDataMap$projectID
        container = assetDataMap$container
        region = assetDataMap$region
        userID = assetDataMap$userID
        password = assetDataMap$password
        authURL = assetDataMap$authURL
        
        rdd <- NULL
        authResponse = authenticateWithObjectStore(pc, authURL, userID, password, projectID)
        if (authResponse$status_code == RC_Created_OK || authResponse$status_code == RC_OK) {
          
          
          authResponseBody = jsonlite::fromJSON(httr::content(authResponse, 'text', encoding="UTF-8"))
          if (isOnPrem(pc)){
            # OnPrem version
            authToken <- authResponseBody$access$token$id
            log(paste("Object Store auth token is", authToken))
            # End of onPrem version
          } else {
            # Cloud Version
            authToken = authResponse$header$'x-subject-token'
            log(paste("Object Store auth token is", authToken))
            # End of Cloud Version
          }
          
          objStoreURL = getObjectStoreURLFromAuthResponseBody(pc, authResponseBody, region, container, fileName)
          log(paste("Object Store URL is", objStoreURL))
          
          filePath = file.path(pc$home, 'data', fileName, fsep = .Platform$file.sep)
          loadResponse = httr::GET(objStoreURL, httr::accept_json(), httr::add_headers('X-Auth-Token' =authToken))
          if (loadResponse$status_code == RC_OK) {
              fileData <- httr::content(loadResponse, 'text', encoding = "UTF-8")
              log(paste("filePath =", filePath))
              writeBin(fileData, filePath)
            
              rdd <- SparkR:::textFile(sc, filePath)
              
              # delete file
              # log(paste("Deleting temp file: ", filePath))
              # file.remove(filePath)

          } else {
                log(paste("File data could not be loaded from the Object Store for " , filename , ", RC = " , authResponse$status_code))
                #createErrorRDD(pc, "RDD could not be created from Object Store asset")
          }
        } else {
            log(paste("Authorization could not be obtained for the Object Store, RC = " , authResponse$status_code))
            #createErrorRDD(pc, "DataFrame could not be created from Object Store asset")
        }
        
        rdd
      }
      ###############################################################################################
      ###                               Store DataFrame to Object store                           ###
      ###                  Usage: result <- storeRDDAsObjectStoreFile(pc, dataframe, "movie5")    ###
      ###############################################################################################
      
#' Stores the content of the given RDD as a new project file with the given name in the Datalake service.
#' @export
        storeRDDAsDatalakeFile<- function (pc, rdd, filename) {
           storeSparkDataObjectAsDatalakeFile(pc,  rdd, filename)
        }
      
#' Stores the content of the given RDD as a new project file with the given name in the Object Store service. 
#' @export
      storeRDDAsObjectStoreFile <- function (pc, rdd, filename){
        storeSparkDataObjectAsObjectStoreFile(pc, rdd, filename)
      }
      
      