###############################################################################
# File:        ProjectUtilObjectStore
# Version:      0.1.0v
# Description:  This script is used for generating API documentation for
#               for Project-notebook-integration's R APIs and creating the
#               projectnb R package
# Author:       Emily Zhang emilyz@us.ibm.com
# Created:      20161212 - listAvailableFilesData(pc)
# Updated:      
#               20161212 - loadDataFrameFromFile
#               20161214 - storeDataFrameAsFile
#               20161214 - update for packaging
###############################################################################
# ProjectUtil
# Usage:
# listAvailableFilesData(pc)

############################################################
# usage: listAvailableFilesData(pc)
############################################################
#'
#'  * Gets storage info from Projects service for the Object Store associated with the project.
#'* Note: if the project is an "Object Store" project, the storage info is defined once for the
#'* entire project.  If the project is a "Catalog" (Data lake) project, then the storage info is
#'* contained in the given asset (file) data object.
#'
#' @export
getStorageInfoForObjectStore <- function(pc, assetData) {
  serviceURL = paste(getProjectsServiceURL(pc), "/", pc$projectID, sep="")
  log(paste("getStorageInfoForObjectStoreURL is", serviceURL))
  httpResponse= httr::GET(serviceURL, httr::accept_json(), httr::add_headers('Authorization' = pc$accessToken))
  storageInfo <- assetData   
  if (httpResponse$status_code == RC_OK) {
    responseBody = jsonlite::fromJSON(httr::content(httpResponse, 'text'))
    log(paste("getStorageInfoForObjectStore responseBody is:", responseBody))
    for (i in 1:length(responseBody)) {
      if (!is.null(responseBody[i]$entity) && responseBody[i]$entity$storage$type == StorageType_ObjectStore) {
        storageInfo <- responseBody[i]$entity$storage
        log("found storageInfo!")
      }
    }  
    log("getStorageInfoForObjectStoreAsset is Ok")
  } else {
    logError(paste("Unexpected response code", httpResponse$status_code, "returned from available files call to Projects Service"))
    storageInfo <- "StorageInfoNotFound"
  }
  storageInfo
}
  
#' Creates and returns a map of the asset data values that we need from the given JSON structure.
#' @export
getAssetDataMap <- function(pc, fileName, storageInfo) {
  assetDataMap = list()
  projectID <- storageInfo$properties$credentials$projectId
  if (is.null(projectID)) projectID <- "project ID not found"
  container <- storageInfo$properties$container
  if (is.null(container)) container <- "container not found"
  region <- storageInfo$properties$credentials$region
  if (is.null(region)) region <- "region not found"
  userID <- storageInfo$properties$credentials$userId
  if (is.null(userID)) userID <- "user ID not found"
  password <- storageInfo$properties$credentials$password
  if (is.null(password)) password <- "password not found"
  authURL <- storageInfo$properties$credentials$auth_url
  if (is.null(authURL)) {
    authURL <- "authURL not found"
  } else {
    authURL <- paste(authURL, "/v3/auth/tokens", sep="")
  }
  
  assetDataMap$fileName <- fileName
  assetDataMap$projectID <- projectID
  assetDataMap$container <-  container
  assetDataMap$region <- region
  assetDataMap$userID <- userID
  assetDataMap$password <- password
  assetDataMap$authURL <- authURL
  assetDataMap
}

#' Authenticates with an Object Store using the given auth URL, user ID, password, and project ID. 
#' @export
authenticateWithObjectStore <- function(pc, authURL, userID, password, projectID) {
    log(paste("authenticate object store, URL =", authURL, ", user ID =", userID, ", project ID = ", projectID))
    requestBodyList = list(
      auth = list(
        identity = list (
          methods = list("password"),
          password = list (
            user = list (
              id =  userID,
              password = password
            )
          )
        ),
        scope = list(
          project = list(
            id = projectID
          )
        )
      )
    )
    requestBody <- jsonlite::toJSON(requestBodyList, auto_unbox = TRUE, pretty = TRUE)
    # httpRequest = Http(authURL).postData(requestBody).header("Content-Type", "application/json")
    httpResponse <- httr::POST(
      url = authURL,
      body = requestBody,
      httr::content_type("application/json"),
      httr::accept_json(),
      httr::add_headers(Authorization = pc$accessToken),
      httr::verbose()
    )
    httpResponse
  }

#' Derives and returns a URL for accessing the Object Store from the given authorization response body, region, 
#' container, and file name. 
#' @export
getObjectStoreURLFromAuthResponseBody <- function(pc, authResponseBody, requiredRegion, container, fileName){
    
     typeIndex = match('object-store', authResponseBody$token$catalog$type)
     endpoints <- authResponseBody$token$catalog$endpoints[typeIndex][[1]]
     urlInd = which((endpoints[,3]==requiredRegion & endpoints[,4]=="public"))
     urlStr = endpoints[urlInd, 2]
    
    objectStoreURL = paste(urlStr, "/", gsub(" ", "%20", container), "/", gsub(" ", "%20", fileName), sep="")
    objectStoreURL
  }

#' @export   
loadFileFromObjectStore <- function (pc, objStoreURL, filePath, authToken) {
  # httpRequest = Http(objStoreURL).header("X-Auth-Token", authToken)
  httpRequest = httr::GET(objStoreURL, httr::accept_json(), httr::add_headers('X-Auth-Token' =authToken))
  # httpResponse = httpRequest.execute[File](parser = {inputStream => loadFileFromInputStream(pc, inputStream, filePath) })
  httpRequest
}

#' Gets a data frame for the ObjectStore asset represented by the given asset data. 
#' @export    
getDataFrameForObjectStoreAsset <-function(pc, assetData, storageInfo, fileName){
    assetDataMap = getAssetDataMap(pc, fileName, storageInfo)
    
    projectID = assetDataMap$projectID
    container = assetDataMap$container
    region = assetDataMap$region
    userID = assetDataMap$userID
    password = assetDataMap$password
    authURL = assetDataMap$authURL
    
    dataFrame <- NULL
    authResponse = authenticateWithObjectStore(pc, authURL, userID, password, projectID)
    if (authResponse$status_code == RC_Created_OK) {
        #authResponseHeaders <- authResponse$headers
        authToken = authResponse$header$'x-subject-token'
        log(paste("Object Store auth token is", authToken))
        #fileData <- jsonlite::fromJSON(httr::content(availFilesResponse, 'text'))
        authResponseBody = jsonlite::fromJSON(httr::content(authResponse, 'text', encoding="UTF-8"))
        objStoreURL = getObjectStoreURLFromAuthResponseBody(pc, authResponseBody, region, container, fileName)
        log(paste("Object Store URL is", objStoreURL))
        filePath = file.path(pc$home, 'data', fileName, fsep = .Platform$file.sep)
        #loadResponse = loadFileFromObjectStore(pc, objStoreURL, filePath, authToken)
        loadResponse = httr::GET(objStoreURL, httr::accept_json(), httr::add_headers('X-Auth-Token' =authToken))
        if (loadResponse$status_code == RC_OK) {
          #dataFrame = getDataFrameFromFile(pc, filePath)
          fileData <- httr::content(loadResponse, 'text', encoding = "UTF-8")
          log(paste("filePath =", filePath))
          writeBin(fileData, filePath)
          log("About to call Spark-CSV service to create a DataFrame")
          asset_df <- read.csv(file = filePath, header=TRUE, quote = "\"", skipNul = TRUE)
          dataFrame <- createDataFrame(sqlContext, asset_df)
          log("Call to Spark-CSV service completed")
        } else {
          logError(paste("File data could not be loaded from the Object Store for ", fileName, ", RC = ", loadResponse$status_code, sep=""))
        }
      }
      else {
        logError(paste("Authorization could not be objtained for the Object Store, RC =", authResponse$status_code))
        #createErrorDataFrame(pc, "DataFrame could not be created from Object Store asset")
      }
    dataFrame
  }

###############################################################################################
###                               Store DataFrame to Object store                               ###
###                  Usage: result <- storeDataFrameAsObjectStoreFile(pc, dataframe, "movie5")               ###
###############################################################################################
#' Gets data for Object Store files available to the current user from the Projects Service.  The result is 
#' an array of strings representing an HTTP response. */
#' @export
  getAvailableObjectStoreFilesDataFromProjectsService <- function(pc) {
    url = composeServiceURL(getProjectsServiceURL(pc), pc$projectID, PSEPAssets, "", 
                            paste(PSParamType, paste(PSParamValueObjStoreFile, sep=","), sep="="))
                            # List((PSParamType, List(PSParamValueObjStoreFile))))
    log(paste("getAvailableObjectStoreFilesFromProjectsService URL is", url))
    #httpResponse = Http(url).headers(Seq(AuthHeader -> pc.accessToken)).asString
    httpResponse = httr::GET(url, httr::accept_json(), httr::add_headers('Authorization' = pc$accessToken))
    httpResponse
  }


#' Writes the given file content to the Object storage provider using the given URL. 
#' @export
writeAssetToObjectStore <- function (pc, objStoreURL, filePath, authToken) {

    log(paste("Writing content of", filePath, "to Object Store as", objStoreURL))
    #log (paste("Authorization =", pc$accessToken))
    r <-httr::PUT( url = objStoreURL, body = httr::upload_file(filePath), 
                   httr::add_headers('X-Auth-Token' =authToken, "MIME-Type"= "application/csv"))
    log(paste("PUT Status code for assetURL", r$status_code))
    r
  }

#' Posts an Object Store asset with the given guid and URL to the Projects service.  The result is an array of strings 
#' representing an HTTP response. 
#' @export
postObjectStoreAssetToProjectsService <- function(pc, fileName, propertiesHash) {
    serviceURL = composeServiceURL(getProjectsServiceURL(pc), pc$projectID, PSEPAssets, "", "" )
    log(paste("postAssetToProjectsService URL is", serviceURL))

    dataList <- list ( assets =
                     list(
                       list(
                         type = ObjectStoreFiletypeID,
                         name  = fileName,
                         mime_type = "text/csv",
                         url = "#",
                         properties =
                           list(id =  fileName,
                                hash = propertiesHash,
                                project_storage = TRUE)
                       )))
    data <- jsonlite::toJSON(dataList, auto_unbox = TRUE, pretty = TRUE)
    log(paste("Asset data for postAssetToProjectsService is ", data))
    #httpResponse = Http(url).postData(assetData).headers(Seq("Authorization" -> pc.accessToken, 
    #"Content-Type" -> "application/json")).asString
    httpResponse <- httr::POST(
      url = serviceURL,
      body = data,
      httr::content_type("application/json"),
      httr::accept_json(),
      httr::add_headers(Authorization = pc$accessToken),
      httr::verbose()
    )
    httpResponse
  }

#' Adds an Object Store file to the current project. 
#' @export
addObjectStoreFileAssetToProject <- function (pc, fileName, propertiesHash){
    addFileAssetToProjectResult = FALSE
    httpResponse = postObjectStoreAssetToProjectsService(pc, fileName, propertiesHash)
    addFileAssetToProjectResult = (httpResponse$status_code == RC_OK)
    if (addFileAssetToProjectResult)  {
        log("Post asset to project service was successful!")
    } else {
        log(paste("Posting asset to project service failed, RC is", httpResponse$status_code))
    }
    addFileAssetToProjectResult
  }

# Returns a list of file data objects from the given file data JSON string.
#' @export
getFirstObjectStoreAssetData <- function(pc, filesData) {
  #fileDataList <- list()
  firstAssetData <- NULL
  fileData <- jsonlite::fromJSON(httr::content(filesData, 'text'))
  for (i in 1:length(fileData$assets$name)) {
    fileDataList = append (fileDataList, paste ("name =", fileData$assets$name[i],
                                                ", type =", fileData$assets$type[i], sep=""))
  }
  fileDataList
}

#' Stores the content of the given Spark data object as a new project file with the given name in the Object Store 
#'  service. 
#'  @export
  storeSparkDataObjectAsObjectStoreFile <- function(pc, sdo, fileName) {
    storeResult = FALSE
    checkResultOpt = checkIfFileExistsInDatalake(pc, fileName)
    if (checkResultOpt) {
      logError(paste("A file with name", fileName, "already exists."))
    } else {
     httpResponse = getAvailableObjectStoreFilesDataFromProjectsService(pc)
     if (httpResponse$status_code ==  RC_OK)  {
        log("RC OK from getAvailableObjectStoreFilesDataFromProjectsService call")
        assetDataList <- jsonlite::fromJSON(httr::content(httpResponse, 'text'))
        if (is.null(assetDataList) || is.null(assetDataList$assets) || length(assetDataList$assets$name) == 0) {
           logError("You need to have at least one Object Store file in your project before you can store one from your notebook")
        }
        else {
             #filteredAssetDataList = assetDataList.filter( x => (x \ "name").values.toString.equals(fileName))
             #assetData = assetDataList[1]
             storageInfo = getStorageInfoForObjectStore(pc, assetDataList)
             tempFileName = assetDataList$assets$name[1]
             tempPropertiesHash = "" #assetDataList$assets$properties$hash[1]
             assetDataMap = getAssetDataMap(pc, tempFileName, storageInfo)
            
             authURL = assetDataMap$authURL
             userID = assetDataMap$userID
             password = assetDataMap$password
             projectID = assetDataMap$projectID
             region = assetDataMap$region
             container = assetDataMap$container
            
             authResponse = authenticateWithObjectStore(pc, authURL, userID, password, projectID)
             if (authResponse$status_code== RC_Created_OK ) {
                 #authResponseHeaders = authResponse.headers
                 #authTokenOpt = authResponseHeaders.get("X-Subject-Token")
                 #authTokenSeq = authTokenOpt.getOrElse(IndexedSeq("No_auth_token_found"))
                 #authToken = authTokenSeq(0)
                 authToken = authResponse$header$'x-subject-token'
                 log(paste("Object Store auth token is ", authToken))
                 
                 #authResponseBody = authResponse.body
                 #objStoreURL = getObjectStoreURLFromAuthResponseBody(pc, authResponseBody, region, container, fileName)
                 #log(paste("Object Store URL is ", objStoreURL))
                 authResponseBody = jsonlite::fromJSON(httr::content(authResponse, 'text', encoding="UTF-8"))
                 objStoreURL = getObjectStoreURLFromAuthResponseBody(pc, authResponseBody, region, container, fileName)
                 log(paste("Object Store URL is", objStoreURL))
                 
                 filePath = createFileFromSparkDataObject(pc, sdo, fileName)
                 log(paste("New file is at ", filePath))
                 #filePath = file.getPath
                 #log(paste("Getting line iterator for file ", filePath))
                 #source = Source.fromFile(filePath)
                 #lineIter = source.getLines
                 writeRC = writeAssetToObjectStore(pc, objStoreURL, filePath, authToken)
                 if (writeRC$status_code == RC_Created_OK) {
                     display("DataFrame write to storage service succeeded!")
                     #renderedProps = render(modifiedAssetProperties)
                     #propertiesStr = compact(renderedProps)
                     addFileAssetToProjectResult = addObjectStoreFileAssetToProject(pc, fileName, tempPropertiesHash)
                     display(paste("Add data asset to project", if (addFileAssetToProjectResult) "succeeded!" else "failed!"))
                     storeResult = addFileAssetToProjectResult
                     display("Storing DataFrame completed.")
                  } else {
                    logError(paste("File write to Object Store failed! Responde code = ", writeRC))
                  }
                
                log(paste("Deleting temp file:", filePath))
                #file.delete
                file.remove(filePath)
              }   
              else {
                log(paste("Authorization could not be objtained for the Object Store, RC =", authResponse$status_code))
              }
        }
      }
      else {
        logError(paste("Unexpected response code", httpResponse$status_code, "returned when storing file to Object Store"))
      }
     }

    storeResult
  }

#' Stores the content of the given data frame as a new project file with the given name in the Object Store 
#' service. 
#' @export
  storeDataFrameAsObjectStoreFile <- function (pc, df, fileName){
    display ("Storing DataFrame, this will take a few moments...")
    storeSparkDataObjectAsObjectStoreFile(pc, df, fileName)
  }
