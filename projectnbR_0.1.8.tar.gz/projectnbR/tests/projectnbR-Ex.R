###############################################################################
# File:        TestProjectUtil
# Version:      0.1.0v
# Description:  This script is used for generating API documentation for
#               for Project-notebook-integration's R APIs and creating the
#               projectnb R package
# Author:       Emily Zhang emilyz@us.ibm.com
# Created:      20161207
# Update:       20161210
###############################################################################

##### Data lake ##### 
library(projectnbR)
projectID <- "72a068ef-16af-4c8f-986e-e87229242418";
accessToken <- "p-2fb720b5a707c01c57c119ba294d7dedb9179285"
pc <- ProjectContext(sc, projectID, accessToken)
listAvailableFilesData(pc)
# pick up a datalake file
df <- loadDataFrameFromFile(pc, "movies.csv")
head (df)

df2 <- select(df, "Title", "Year")
df3 <- where (df2, df2$Year > 1970)
head(df3)

result <- storeDataFrameAsFile(pc, df3, "movie6")
if (result) print("Write to Datalake succeeded!") else print("Write to Datalake failed!")

listAvailableFilesData(pc)

#####  Object Store ##### 
library(projectnbR)
projectID <- "156be706-0d73-41f0-b4bc-1942b335abcd";
accessToken <- "p-a0d87f098dd679748c996624ee337714bff818d9"
pc <- ProjectContext(sc, projectID, accessToken)
listAvailableFilesData(pc)
# pick up an object store file
df <- loadDataFrameFromFile(pc, "moviesObjStore.csv")
head (df)

df2 <- select(df, "Title", "X_Year")
df3 <- where (df2, df2$X_Year > 1970)
head(df3)

result <- storeDataFrameAsObjectStoreFile(pc, df3, "movie5")
if (result) print("Write to Datalake succeeded!") else print("Write to Datalake failed!")

listAvailableFilesData(pc)