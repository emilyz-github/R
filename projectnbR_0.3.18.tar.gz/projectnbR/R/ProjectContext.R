###############################################################################
# Class:        ProjectContext
# Version:      0.1.0v
# Description:  This script is used for generating API documentation for
#               for Project-notebook-integration's R APIs and creating the
#               projectnb R package
# Author:       Emily Zhang emilyz@us.ibm.com
# Created:      20161015
# Updated:      20161021 - clean up
#               20161209 - update for packaging
#               20161216 - update ProjectContext to support missing parameters
#               20161216 - update comments/documents
###############################################################################

# Usage example:
#   pc <- ProjectContext(sc, "a74c4cf6-45c2-49ac-b948-705180bc7410", "p-0b3365a66f240bea812526d475f62a09cc077d94")
#   pc$projectID
#   pc$home

ENV_HOME = 'HOME'
HOME_NOT_FOUND <- "/notHome"
ENV_ID_prod <- "prod"
ENV_ID_qa <- "qa"
ENV_ID_YS1_prod <- "YS1 prod"
ENV_ID_dev <- "dev"
ENV_ID_onPrem <- "on-prem"
INVALID_ENV_ID <- "invalid_environment_identifier"

RUNTIME_ENV_STOREFRONT <- "RUNTIME_ENV_STOREFRONT"
RUNTIME_ENV_NOTEBOOK <- "RUNTIME_ENV_NOTEBOOK"
ENV_STOREFRONT_BLUEMIX_PROD <- "bluemix/prod"
ENV_STOREFRONT_BLUEMIX_STAGING <- "bluemix/staging"
ENV_STOREFRONT_ONPREM <- "on-prem"

ENV_NOTEBOOK_PROD <- "prod"
ENV_NOTEBOOK_QA <- "staging"
ENV_NOTEBOOK_DEV <- "dev"
ENV_NOTEBOOK_ONPREM <- "on-prem"

#' Checks the given string to see if it starts with "Bearer". If so, the string is returned as-is.
#' If not, it is returned pre-pended with "Bearer".
fixToken <- function(raw_token){
        if (substr(raw_token, 1, nchar("Bearer ")) == "Bearer "){
            token <- raw_token
        }
        else if (substr(raw_token, 1, nchar("bearer "))== "bearer "){
            token <- paste ("B" , substring(raw_token, 2), sep="")
        }
        else {
            token <- paste ("Bearer ", raw_token, sep="")
        }
        token
}

#' Gets and returns the current home directory in the runtime environment.
#' @export
getHomeDir <- function() {
      homeDir <- Sys.getenv(ENV_HOME)
      if (homeDir == '') {
          homeDir <- HOME_NOT_FOUND
      }
      homeDir
}

#' Gets and returns the runtime environment: "prod", "qa", "dev" or "YS1 prod" or "on-prem"
#' @export
getEnvironment <- function() {
      runtime_env_storefront <- Sys.getenv(RUNTIME_ENV_STOREFRONT)
      runtime_env_notebook <- Sys.getenv(RUNTIME_ENV_NOTEBOOK)
      envID <- INVALID_ENV_ID
      if (runtime_env_storefront == ENV_STOREFRONT_BLUEMIX_PROD) {
          if (runtime_env_notebook == ENV_NOTEBOOK_PROD) {
              envID <- ENV_ID_prod
          } else if (runtime_env_notebook == ENV_NOTEBOOK_QA) {
              envID <- ENV_ID_qa
          }
      } else if (runtime_env_storefront == ENV_STOREFRONT_BLUEMIX_STAGING){
          if (runtime_env_notebook == ENV_NOTEBOOK_PROD) {
              envID <- ENV_ID_YS1_prod
          } else if (runtime_env_notebook == ENV_NOTEBOOK_DEV) {
              envID <- ENV_ID_dev
          }
      } else if  (runtime_env_storefront == ENV_STOREFRONT_ONPREM){
        if (runtime_env_notebook == ENV_NOTEBOOK_ONPREM) {
          envID <- ENV_ID_onPrem
        }
      }
      envID
}

#' The ProjectContext contains all the information needed to work with the Projects service
#' in a Spark notebook. 
#' 
#' @param sc_val the SparkContext to use with the notebook
#' @param project_id_val the ID of the project to use within the notebook.  The project ID is the project
#' "guid", that is, a generated ID.
#' @param access_token_val a project-specific access token to use to authenticate with the Projects service 
#' @param home_val the home location for the notebook in the GPFS (General-Purpose File System), which is 
#' used to store temporary files
#' @param env_val the current execution environment.  It is one of "prod", "qa", "dev", or "YS1 prod", or "on-prem"
#' @param debug_val a debug flag used by the project-notebook-integration utility
#' @keywords ProjectContext
#' @export
ProjectContext <- function(sc_val, project_id_val, access_token_val, home_val, env_val, debug_val)
{
  
  me <- list(
    sc = sc_val,
    projectID = project_id_val,
    accessToken = fixToken(access_token_val),
    home = if (missing(home_val)) getHomeDir() else home_val,
    environment = if (missing(env_val)) getEnvironment() else env_val,
    debug = if (missing(debug_val)) FALSE else debug_val
  )
  
  ## Set the name for the class
  class(me) <- append(class(me), "ProjectContext")
  return(me)
}

