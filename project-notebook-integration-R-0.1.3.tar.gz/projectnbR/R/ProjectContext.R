###############################################################################
# Class:        ProjectContext
# Version:      0.1.0v
# Description:  This script is used for generating API documentation for
#               for Project-notebook-integration's R APIs and creating the
#               projectnb R package
# Author:       Emily Zhang emilyz@us.ibm.com
# Created:      20161015
# Updated:      20161021 - clean up
#               20161209 - update for packaging
###############################################################################

# Usage example:
#   pc <- ProjectContext(sc, "a74c4cf6-45c2-49ac-b948-705180bc7410", "p-0b3365a66f240bea812526d475f62a09cc077d94")
#   pc$projectID
#   pc$home

ENV_HOME = 'HOME'
HOME_NOT_FOUND <- "/notHome"
ENV_ID_prod <- "prod"
ENV_ID_qa <- "qa"
ENV_ID_YS1_prod <- "YS1 prod"
ENV_ID_dev <- "dev"
INVALID_ENV_ID <- "invalid_environment_identifier"

RUNTIME_ENV_STOREFRONT <- "RUNTIME_ENV_STOREFRONT"
RUNTIME_ENV_NOTEBOOK <- "RUNTIME_ENV_NOTEBOOK"
ENV_STOREFRONT_BLUEMIX_PROD <- "bluemix/prod"
ENV_STOREFRONT_BLUEMIX_STAGING <- "bluemix/staging"
ENV_NOTEBOOK_PROD <- "prod"
ENV_NOTEBOOK_QA <- "staging"
ENV_NOTEBOOK_DEV <- "dev"

fixToken <- function(raw_token){
        if (substr(raw_token, 1, nchar("Bearer ")) == "Bearer "){
            token <- raw_token
        }
        else if (substr(raw_token, 1, nchar("bearer "))== "bearer "){
            token <- paste ("B" , substring(raw_token, 2), sep="")
        }
        else {
            token <- paste ("Bearer ", raw_token, sep="")
        }
        token
      }

#' @export
getHomeDir <- function() {
      homeDir <- Sys.getenv(ENV_HOME)
      if (homeDir == '') {
          homeDir <- HOME_NOT_FOUND
      }
      homeDir
}

#' @export
getEnvironment <- function() {
      runtime_env_storefront <- Sys.getenv(RUNTIME_ENV_STOREFRONT)
      runtime_env_notebook <- Sys.getenv(RUNTIME_ENV_NOTEBOOK)
      envID <- INVALID_ENV_ID
      if (runtime_env_storefront == ENV_STOREFRONT_BLUEMIX_PROD) {
          if (runtime_env_notebook == ENV_NOTEBOOK_PROD) {
              envID <- ENV_ID_prod
          } else if (runtime_env_notebook == ENV_NOTEBOOK_QA) {
              envID <- ENV_ID_qa
          }
      } else if (runtime_env_storefront == ENV_STOREFRONT_BLUEMIX_STAGING){
          if (runtime_env_notebook == ENV_NOTEBOOK_PROD) {
              envID <- ENV_ID_YS1_prod
          } else if (runtime_env_notebook == ENV_NOTEBOOK_DEV) {
              envID <- ENV_ID_dev
          }
      }
      envID
}

#' A ProjectContext
#'
#' This function allows you to construct a ProjectContext.
#' @param sc sc
#' @param projectId project ID
#' @param accessToken access token
#' @keywords ProjectContext
#' @export
#' @examples
#' ProjectContext()
ProjectContext <- function(sc_val, project_id_val, access_token_val)
{

        me <- list(
                sc = sc_val,
                projectID = project_id_val,
                accessToken = fixToken(access_token_val),
                home = getHomeDir(),
                debug = FALSE,
                environment = getEnvironment()
       )

        ## Set the name for the class
        class(me) <- append(class(me),"ProjectContext")
        return(me)
}

